package com.thezili.thezilimirror;

/**
 * Created by JunChangWook on 2016. 9. 30..
 */
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.support.v7.app.ActionBarActivity;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;

public class MainActivity extends ActionBarActivity {

    private String TAG = "THE ZILI MIRROR";
    private Context mContext;

    private Intent intent;
    private ImageButton imgButSpeech;
    private TextView tvResult;
    private TextView tvInfo;

    private SpeechRecognizer mSpeechRecognizer;

    private String inputSTT;
    private String urlCommand;
    private String mirrorIp;
    private SharedPreferences preference;

    private Boolean commanding = false;

    UrlComandTask UrlComandTask;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main_activity);

        mContext = this;

        imgButSpeech = (ImageButton) findViewById(R.id.userSpeech);
        tvResult = (TextView) findViewById(R.id.tvspeech);
        tvInfo = (TextView) findViewById(R.id.tvinfo);

        intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, getPackageName());
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE,"ko-KR");
        intent.putExtra(RecognizerIntent.EXTRA_PROMPT, "거울에게 말해주세요");
        intent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS,5);

        preference = this.getSharedPreferences("MIRROR", 0);
        mirrorIp = preference.getString("MIRROR_IP", "0.0.0.0");


        StringBuilder sbSubTitle = new StringBuilder("거울아 거울아");

        setTitle(sbSubTitle);
        imgButSpeech.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (v.getId() == R.id.userSpeech) {
                    if(commanding == false) {
                        commanding = true;
                        tvInfo.setText("거울아가 음성 인식 중입니다.");
                        Log.d(TAG,"==CWJUN== imgButSpeech commanding : " +  commanding);
                        mSpeechRecognizer = SpeechRecognizer.createSpeechRecognizer(mContext);
                        mSpeechRecognizer.setRecognitionListener(listener);
                        intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
                        intent.putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, /*getPackageName()*/"com.thezili.thezilimirror");
                        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ko-KR");
                        intent.putExtra(RecognizerIntent.EXTRA_PROMPT, "거울에게 말해주세요");
                        intent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS,3);
                        mSpeechRecognizer.startListening(intent);
                    } else {
                        commanding = false;
                        tvInfo.setText("거울아에게 말해 보세요");
                        Log.d(TAG,"==CWJUN== imgButSpeech commanding : " +  commanding);
                        mSpeechRecognizer.destroy();
                    }
                }
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        // 메뉴버튼이 처음 눌러졌을 때 실행되는 콜백메서드
        // 메뉴버튼을 눌렀을 때 보여줄 menu 에 대해서 정의
        getMenuInflater().inflate(R.menu.main_menu, menu);
        Log.d("test", "onCreateOptionsMenu - 최초 메뉴키를 눌렀을 때 호출됨");
        return true;
    }

    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {
        return super.onPrepareOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();


        switch(id) {
            case R.id.mirror_ip:
                Intent intent=new Intent(MainActivity.this,SettingActivity.class);
                startActivity(intent);
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private RecognitionListener listener = new RecognitionListener() {
        @Override
        public void onReadyForSpeech(Bundle params) {
            Log.d(TAG,"==CWJUN== onReadyForSpeech : " +  params);
            //Toast.makeText(mContext,"거울아 거울아 준비 완료",Toast.LENGTH_SHORT).show();
        }

        @Override
        public void onBeginningOfSpeech() {
            Log.d(TAG,"==CWJUN== onBeginningOfSpeech ");
            //Toast.makeText(mContext,"거울아 거울아 인식 준비 완료",Toast.LENGTH_SHORT).show();
        }

        @Override
        public void onRmsChanged(float rmsdB) {
            Log.d(TAG,"==CWJUN== onRmsChanged ");
        }

        @Override
        public void onBufferReceived(byte[] buffer) {
            Log.d(TAG,"==CWJUN== onBufferReceived ");
        }

        @Override
        public void onEndOfSpeech() {
            Log.d(TAG,"==CWJUN== onEndOfSpeech ");
            //Toast.makeText(mContext,"거울아 거울아 인식 완료",Toast.LENGTH_SHORT).show();
        }

        @Override
        public void onError(int error) {
            Log.d(TAG,"==CWJUN== onError : " +  error);
            tvResult.setText("거울아가 인식에 실패 했습니다");
            tvInfo.setText("거울아에게 말해 보세요");
            commanding = false;
            mSpeechRecognizer.destroy();
        }

        @Override
        public void onResults(Bundle results) {
            String key = "";
            Log.d(TAG,"==CWJUN== onResults : "+ results);
            key = SpeechRecognizer.RESULTS_RECOGNITION;
            inputSTT = results.getStringArrayList(key).get(0);
            /*if(inputSTT.equals("정지")) {
                Toast.makeText(getActivity(),"음성 명령이 정지 되었습니다",Toast.LENGTH_LONG).show();
                mRecognizer.destroy();
                input_sst = "";
                return;
            }*/

            tvResult.setText("" + inputSTT);
            tvInfo.setText("거울아에게 말해 보세요");
            Toast.makeText(mContext,"거울아가 인지한 명령은 : "+inputSTT,Toast.LENGTH_SHORT).show();
            Log.d("","==CWJUN== STT : "+ inputSTT);

            try {
                urlCommand = URLEncoder.encode(inputSTT, "UTF-8");

                UrlComandTask = new UrlComandTask();
                UrlComandTask.execute();
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
            }
            commanding = false;
            mSpeechRecognizer.destroy();

            //mSpeechRecognizer = SpeechRecognizer.createSpeechRecognizer(mContext);
            //mSpeechRecognizer.setRecognitionListener(listener);
            //mSpeechRecognizer.startListening(intent);
        }

        @Override
        public void onPartialResults(Bundle partialResults) {
            Log.d(TAG,"==CWJUN== onPartialResults : ");
            String key = "";
            key = SpeechRecognizer.RESULTS_RECOGNITION;
            String inputSTT = partialResults.getStringArrayList(key).get(0);
            tvResult.setText("" + inputSTT);
            Toast.makeText(mContext,"주인님이 말한 내용은 : "+inputSTT,Toast.LENGTH_SHORT).show();
        }

        @Override
        public void onEvent(int eventType, Bundle params) {
            Log.d(TAG,"==CWJUN== onEvent : ");
        }
    };

    class UrlComandTask extends AsyncTask<Void, Void, Void> {
        /**
         * Parameter
         *  - 1 parmas는 입력
         *  - 2 progress
         *  - 3 result는 리턴 값 */

        @Override
        protected void onPreExecute() {
            /* Thread의 Run과 같은 기능, Thread로 동작 */
            super.onPreExecute();
            Log.d(TAG,"==CWJUN== onPreExecute : ");
        }

        @Override
        protected Void doInBackground(Void... voids) {
            /** 라즈베리 파이2 전송하는 부분 */
            Log.d(TAG,"==CWJUN== doInBackground : ");
            try {
                /* 라즈베리 파이 IP : 9090 (port) */
                String requestUrl = "http://"+mirrorIp+":9090/android.do?command="+urlCommand;
                Log.d("mirror requestUrl : ",requestUrl);
                URL url = new URL(requestUrl);
                HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();

                BufferedReader br = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));

                String response = null;

                while (true) {
                    response = br.readLine();
                    if (response == null) break;
                    Log.d("[android command]","Response : " + response);
                }

                urlConnection.disconnect();

            } catch (Exception e) {
                e.printStackTrace();
            }

            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {

            super.onPostExecute(aVoid);
            Log.d(TAG,"==CWJUN== onPostExecute : ");
        }
    }
}
