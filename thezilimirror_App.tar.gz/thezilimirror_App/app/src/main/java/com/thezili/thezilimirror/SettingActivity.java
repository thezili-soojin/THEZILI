package com.thezili.thezilimirror;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

/**
 * Created by JunChangWook on 2016. 9. 30..
 */

public class SettingActivity extends ActionBarActivity {
    private EditText editIp;
    private TextView tvCurrentIP;
    private Button btSetIP;

    private String mCurrentIp;
    private String mMirrorIp;

    private SharedPreferences preference;
    private SharedPreferences.Editor editor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.setting_activity);

        tvCurrentIP = (TextView)findViewById(R.id.tvCurrentIP);
        editIp = (EditText)findViewById(R.id.editIp);
        btSetIP = (Button)findViewById(R.id.btnSetIP);

        StringBuilder sbSubTitle = new StringBuilder("거울아 IP 설정");

        setTitle(sbSubTitle);

        preference = getSharedPreferences("MIRROR", 0);
        editor = preference.edit();

        mCurrentIp = preference.getString("MIRROR_IP","0.0.0.0");
        tvCurrentIP.setText(mCurrentIp);

        btSetIP.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                mMirrorIp = editIp.getText().toString();
                editor.putString("MIRROR_IP",mMirrorIp);
                editor.commit();
                mCurrentIp = preference.getString("MIRROR_IP","0.0.0.0");
                tvCurrentIP.setText(mCurrentIp);
                editIp.setText("");
            }
        });
    }

}
